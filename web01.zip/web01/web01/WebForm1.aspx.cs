﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace web01
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            lblResult.Text = "Welcome " + tbxName.Text;
            lblTime.Text = string.Format($"The Time is {DateTime.Now.ToLongTimeString()}");
        }
    }
}