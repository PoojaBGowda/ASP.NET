﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace servercontrolsdemo
{
    public partial class imagebuttondemo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if ((e.X >=185 && e.X<=300) && (e.Y >= 161 && e.Y<=168))
            {
                Label1.Text = "the user had clicked in the region";
            }
            else
            {
                Label1.Text = "the user had clicked ouside the region";
            }
        }
    }
}