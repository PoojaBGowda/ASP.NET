﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace servercontrolsdemo
{
    public partial class panelcontrol : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (MultiView1.ActiveViewIndex <= MultiView1.Views.Count)
            {
                MultiView1.ActiveViewIndex += 1;
                Label1.Text = MultiView1.ActiveViewIndex.ToString();
            }
            else
            {
                Label1.Text = "you had reached the end of the views";
            }
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (MultiView1.ActiveViewIndex > 0)
            {
                MultiView1.ActiveViewIndex -= 1;
                Label1.Text = MultiView1.ActiveViewIndex.ToString();
            }
            else
            {
                Label1.Text = "you had reched the start of the views";

            }
           
        }
    }
}