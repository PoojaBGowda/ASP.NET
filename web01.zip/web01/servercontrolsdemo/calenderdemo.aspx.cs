﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace servercontrolsdemo
{
    public partial class calenderdemo : System.Web.UI.Page
    {
        private Hashtable _scheduleData;

        protected void Page_Load(object sender, EventArgs e)
        {
            _scheduleData = GetSchedule();


            Calendar1.Caption = "Personal Schedule";
            Calendar1.FirstDayOfWeek = FirstDayOfWeek.Sunday;
            Calendar1.NextPrevFormat = NextPrevFormat.ShortMonth;
            Calendar1.TitleFormat = TitleFormat.MonthYear;
            Calendar1.ShowGridLines = true;
            Calendar1.DayStyle.HorizontalAlign = HorizontalAlign.Left;
            Calendar1.DayStyle.VerticalAlign = VerticalAlign.Top;
            Calendar1.DayStyle.Height = new Unit(75);
            Calendar1.DayStyle.Width = new Unit(100);
            Calendar1.OtherMonthDayStyle.BackColor = System.Drawing.Color.Cornsilk;
            Calendar1.TodaysDate = new DateTime(2017, 4, 19);
            Calendar1.VisibleDate = Calendar1.TodaysDate;
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            Label1.Text = "selected date is :" + Calendar1.SelectedDate.ToShortDateString();

        }

        protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
        {
            //if (e.Day.Date < DateTime.Now.Date)
            //{
            //    Literal lit = new Literal();
            //lit.Text = "<br />";
            //e.Cell.Controls.Add(lit);
            //    e.Day.IsSelectable = false;
            //}

            if (_scheduleData[e.Day.Date.ToShortDateString()] != null)
            {
                Literal lit = new Literal();
                lit.Text = "<br />";
                e.Cell.Controls.Add(lit);

                Label lbl = new Label();
                lbl.Text = (string)_scheduleData[e.Day.Date.ToShortDateString()];
                lbl.Font.Size = new FontUnit(FontSize.Small);
                e.Cell.Controls.Add(lbl);

            }
        }

        private Hashtable GetSchedule()
        {
            Hashtable schedule = new Hashtable();
            schedule["4/20/2017"] = "this is a culturals day";
            schedule["4/29/2017"] = "sad saturday";
            return schedule;
        }
    }
}