﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;


namespace Finalcasestudy
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        static string connection = ConfigurationManager.ConnectionStrings["InsuranceConn"].ConnectionString;//@"Server=INCHCMPC011397;Database=Insurance;Trusted_Connection=true";
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnregister_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                string command = "Select UserName from tblInsuranceAgents where UserName= '" + txtusername.Text.Trim() + "' ";
                SqlCommand cmd;
                cmd = new SqlCommand(command, con);
                SqlDataReader dr;
                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                if (dr.HasRows)
                {
                    Response.Write("<script>alert('Username you have entered already exists.Please enter another username!')</script>");
                    cmd.Cancel();
                }

                else
                {
                    command = "Insert into tblInsuranceAgents values(@Agent_Id,@FullName,@UserName,@Password,@ConfirmPassword,@Email,@Address,@Gender)";
                    SqlCommand insertagents = new SqlCommand(command, con);
                    insertagents.Parameters.AddWithValue("@Agent_Id", tbxAgentId.Text);
                    insertagents.Parameters.AddWithValue("@FullName", txtname.Text);
                    insertagents.Parameters.AddWithValue("@UserName", txtusername.Text);
                    insertagents.Parameters.AddWithValue("@Password", txtpassword.Text);
                    insertagents.Parameters.AddWithValue("@ConfirmPassword", txtconfirmpassword.Text);
                    insertagents.Parameters.AddWithValue("@Email", txtmail.Text);
                    insertagents.Parameters.AddWithValue("@Address", txtAddress.Text);
                    if (rdMale.Checked == true)
                    {
                        insertagents.Parameters.AddWithValue("@Gender", rdMale.Text);
                    }
                    else if (rdfemale.Checked == true)
                    {
                        insertagents.Parameters.AddWithValue("@Gender", rdfemale.Text);
                    }
                    insertagents.ExecuteNonQuery();
                    MessageBox.Show("You account has been created successfully");
                    Response.Redirect("~/FirstPagee.aspx");

                }
            }
        }
    }
}


