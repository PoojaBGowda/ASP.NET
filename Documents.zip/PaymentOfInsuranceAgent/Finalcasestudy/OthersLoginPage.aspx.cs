﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Finalcasestudy
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        static string connection = ConfigurationManager.ConnectionStrings["InsuranceConn"].ConnectionString;//@"Server=INCHCMPC011397;Database=Insurance;Trusted_Connection=true";

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connection))
                {
                    con.Open();
                    if (dropdownlist.Text == "Insurance Agent")
                    {
                        string command = "Select Agent_Id,Username,Password from tblInsuranceAgents where Agent_Id = '" + txtEmployeeId.Text.Trim() + "'" + "AND  Password = '" + txtpassword.Text.Trim() + "'";
                        using (SqlCommand cmd = new SqlCommand(command, con))
                        {
                            SqlDataReader reader = cmd.ExecuteReader();
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Session["AgentId"] = reader["Agent_Id"].ToString();
                                    Session["UserName"] = reader["UserName"].ToString();
                                    Session["Password"] = reader["Password"].ToString();
                                    Response.Redirect("~/InsAgentHomePage.aspx",false);
                                    MessageBox.Show("Valid UserName and Password");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Invalid UserName or Password");
                                txtEmployeeId.Text = " ";
                                txtpassword.Text = " ";
                            }
                        }
                    }

                    else if (dropdownlist.Text == "Manager")
                    {
                        string command = "Select * from Manager where Manager_Id = '" + txtEmployeeId.Text.Trim() + "'" + "AND  Manager_Password = '" + txtpassword.Text.Trim() + "'";
                        using (SqlCommand cmd = new SqlCommand(command, con))
                        {
                            SqlDataReader reader = cmd.ExecuteReader();
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Session["ManagerId"] = reader["Manager_Id"].ToString();
                                    Session["UserName"] = reader["Manager_Name"].ToString();
                                    Session["Password"] = reader["Manager_Password"].ToString();
                                    Response.Redirect("~/ManagerHomePage.aspx",false);
                                    MessageBox.Show("Valid UserName and Password");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Invalid UserName or Password");
                                txtEmployeeId.Text = " ";
                                txtpassword.Text = " ";
                            }
                        }
                    }

                    //else if (dropdownlist.Text == "Administrator")
                    //{
                    //    string command = "Select Username,Password,AdminId from Administrators where AdminId = '" + txtEmployeeId.Text.Trim() + "'" + "AND  Password = '" + txtpassword.Text.Trim() + "'";
                    //    using (SqlCommand cmd = new SqlCommand(command, con))
                    //    {
                    //        SqlDataReader reader = cmd.ExecuteReader();
                    //        if (reader.HasRows)
                    //        {
                    //            while (reader.Read())
                    //            {
                    //                Session["AdminId"] = reader["AdminId"].ToString();
                    //                Session["UserName"] = reader["UserName"].ToString();
                    //                Session["Password"] = reader["Password"].ToString();
                    //                //Response.Redirect("~/FirstPagee.aspx");
                    //                MessageBox.Show("Valid UserName and Password");
                    //            }


                    //        }
                    //        else
                    //        {
                    //            MessageBox.Show("Invalid UserName or Password");
                    //            txtEmployeeId.Text = " ";
                    //            txtpassword.Text = " ";
                    //        }
                    //    }
                    //}

                    else
                    {
                        MessageBox.Show("Please select the Login AS");
                    }

                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
           
        }


        
    }
}