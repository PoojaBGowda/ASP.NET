﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Finalcasestudy
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        static string connection = ConfigurationManager.ConnectionStrings["InsuranceConn"].ConnectionString;//@"Server=INCHCMPC011397;Database=Insurance;Trusted_Connection=true";

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
           

        }
    }
}