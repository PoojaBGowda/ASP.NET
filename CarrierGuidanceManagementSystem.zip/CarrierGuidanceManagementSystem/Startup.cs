﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CarrierGuidanceManagementSystem.Startup))]
namespace CarrierGuidanceManagementSystem
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
