﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Finalcasestudy
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        static string connection = ConfigurationManager.ConnectionStrings["InsuranceConn"].ConnectionString;//@"Server=INCHCMPC011397;Database=Insurance;Trusted_Connection=true";

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connection))
                {
                    con.Open();
                    
                        string command = "Select userid,Password from Customers where userid = '" + txtuserid.Text.Trim() + "'" + "AND  Password = '" + txtpassword.Text.Trim() + "'";
                        using (SqlCommand cmd = new SqlCommand(command, con))
                        {
                            SqlDataReader reader = cmd.ExecuteReader();
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Session["userid"] = reader["userid"].ToString();
                                  //  Session["UserName"] = reader["UserName"].ToString();
                                    Session["Password"] = reader["Password"].ToString();
                                    Response.Redirect("~/InsAgentHomePage.aspx", false);
                                    MessageBox.Show("Valid UserName and Password");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Invalid UserName or Password");
                            txtuserid.Text = " ";
                                txtpassword.Text = " ";
                            }
                        }
                    }


                
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }
    }
}