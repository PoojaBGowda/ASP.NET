﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Finalcasestudy
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        static string connection = ConfigurationManager.ConnectionStrings["InsuranceConn"].ConnectionString;//@"Server=INCHCMPC011397;Database=Insurance;Trusted_Connection=true";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnregister_Click(object sender, EventArgs e)
        {
            int userid = genRandomnum(4);
            int password = genRandomnum(8);
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                string command = "Select userid from Customers where userid= '" + userid+ "' ";//
                SqlCommand cmd;
                cmd = new SqlCommand(command, con);
                SqlDataReader dr;
                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                if (dr.HasRows)
                {
                    Response.Write("<script>alert('Username you have entered already exists.Please enter another username!')</script>");
                    cmd.Cancel();
                }

                else
                {
                    command = "Insert into Customers values (@FullName,@userid,@Password,@Email,@Address,@Gender)";
                    SqlCommand cmd1 = new SqlCommand(command, con);
                   
                    cmd1.Parameters.AddWithValue("@FullName", txtname.Text);
                    cmd1.Parameters.AddWithValue("@userid", userid);
                    cmd1.Parameters.AddWithValue("@Password", password);
                    //cmd1.Parameters.AddWithValue("@ConfirmPassword", txtconfirmpassword.Text);
                    cmd1.Parameters.AddWithValue("@Email", txtmail.Text);
                    cmd1.Parameters.AddWithValue("@Address", Txtaddress.Text);
                    if (rdMale.Checked == true)
                    {
                        cmd1.Parameters.AddWithValue("@Gender", rdMale.Text);
                    }
                    else if (rdfemale.Checked == true)
                    {
                        cmd1.Parameters.AddWithValue("@Gender", rdfemale.Text);
                    }
                    
                    cmd1.ExecuteNonQuery();
                    MessageBox.Show("You account has been created successfully");
                    Response.Redirect("~/FirstPagee.aspx");           

                }
                
            }
        }

        protected static int genRandomnum(int size)
        {
            int num = 0;
            Random r = new Random();
            string w = "";
            int i;
            for (i = 0; i < size; i++)
            {
                w += r.Next(0, 9).ToString();
            }
            if (w.Length == size-1)
            {
                num = Convert.ToInt32(w);

            }
            return num;
        }
    }


}

//using (SqlCommand cmd = new SqlCommand(command, con))
//{

//    cmd.Parameters.AddWithValue("@FullName", txtname);
//    cmd.Parameters.AddWithValue("@UserName", txtusername);
//    cmd.Parameters.AddWithValue("@Password", txtpassword);
//    cmd.Parameters.AddWithValue("@ConfirmPassword", txtconfirmpassword);
//    cmd.Parameters.AddWithValue("@Email", txtmail);
//    cmd.Parameters.AddWithValue("@Address", Txtaddress);
//    if (rdMale.Checked == true)
//    {
//        cmd.Parameters.AddWithValue("@Gender", rdMale);
//    }
//    else if(rdfemale.Checked == true)
//    {
//        cmd.Parameters.AddWithValue("@Gender", rdfemale);
//    }
//Response.Redirect("~/FirstPagee.aspx");

//cmd.ExecuteNonQuery();

//}

/*

     if (rbtAccept.Checked.ToString() == "True")
   {
       cn2 = new SqlConnection(ConfigurationManager.ConnectionStrings["OHDConn"].ConnectionString);
       cn2.Open();
       string queryForUserName = "Select USERNAME from register where USERNAME= '" + txtUname.Text.Trim() + "' ";

       cmdForUserName = new SqlCommand(queryForUserName, cn2);
       dr = cmdForUserName.ExecuteReader(CommandBehavior.CloseConnection);
       if (dr.HasRows)
       {
           Response.Write("<script>alert('Username you have entered already exists.Please enter another username!')</script>");
       }
       else
       {


           if (rbtMale.Checked == true)
           {
               txtGender = "Male";
           }
           else if (rbtFemale.Checked == true)
           {
               txtGender = "Female";
           }


           cn = new SqlConnection(ConfigurationManager.ConnectionStrings["OHDConn"].ConnectionString);
           cn.Open();
           string str = "insert register(FIRSTNAME,LASTNAME,USERNAME,PASSWORD,RETYPE_PASSWORD,EMAIL_ADDRESS,Department,SEMSTER,ADDRESS,MOBILE_NO,GENDER)" + " values('" + txtFname.Text.Trim() + "','" + txtLname.Text.Trim() + "','" + txtUname.Text.Trim() + "','" + txtPassword.Text.Trim() + "','" + txtRpswd.Text.Trim() + "','" + txtEmail.Text.Trim() + "','" + ddlDept.SelectedValue + "'," + txtSem.Text.Trim() + ",'" + txtAdd.Text.Trim() + "', " + txtMob.Text.Trim() + ",'" + txtGender + "')";
           cmd = new SqlCommand(str, cn);
           cmd.ExecuteNonQuery();


           conUserID = new SqlConnection(ConfigurationManager.ConnectionStrings["OHDConn"].ConnectionString);
           conUserID.Open();
           queryForUserID = "Select userID from register where USERNAME= '" + txtUname.Text.Trim() + "' ";

           cmdForUserID = new SqlCommand(queryForUserID, conUserID);
           drForUserID = cmdForUserID.ExecuteReader(CommandBehavior.CloseConnection);


           while (drForUserID.Read())
           {
               string userIdFetch = drForUserID["userID"].ToString();
               Session["uID"] = userIdFetch;

           }




           Response.Write("<script>alert('You have successfully created your account!')</script>");
       }
   }
   else
   {
       Response.Write("<script>alert('You have chosen not to register!')</script>");
   }

*/

